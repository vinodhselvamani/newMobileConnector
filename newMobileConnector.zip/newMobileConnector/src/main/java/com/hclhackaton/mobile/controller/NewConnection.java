package com.hclhackaton.mobile.controller;

import org.springframework.web.bind.annotation.*;

@RestController
public class NewConnection {

	public NewConnection() {
		// TODO Auto-generated constructor stub
	}



}
