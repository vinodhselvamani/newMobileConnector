package com.hclhackaton.mobile.controller;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;

import java.util.HashMap;
import java.util.Map;

public class InputDataFields {

    private Map<String,String> fields = new HashMap<>();

    @JsonAnyGetter
    public Map<String,String> getInputFields() {
        return fields;
    }

    @JsonAnySetter
    public void addInputField(String key, String value) {
        fields.put(key, value);
    }

    @Override
    public String toString() {
        StringBuilder toStringOutput = new StringBuilder("InputDataFields{").append("fields=[");

        for (Map.Entry<String,String> entry: fields.entrySet()) {
            toStringOutput.append("\"").append(entry.getKey()).append("\"");
            toStringOutput.append("\"").append(entry.getValue()).append("\",");
        }
        toStringOutput.replace(toStringOutput.length(),toStringOutput.length(), "");
        toStringOutput.append("]}");

        return toStringOutput.toString();
    }
}
