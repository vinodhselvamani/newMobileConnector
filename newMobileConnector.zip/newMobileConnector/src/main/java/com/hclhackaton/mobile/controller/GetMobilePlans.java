package com.hclhackaton.mobile.controller;

public class GetMobilePlans {

	public GetMobilePlans() {
		// TODO Auto-generated constructor stub
	}

}
