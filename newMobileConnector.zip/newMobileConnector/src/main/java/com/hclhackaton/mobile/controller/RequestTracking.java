package com.hclhackaton.mobile.controller;

public class RequestTracking {

	public RequestTracking() {
		// TODO Auto-generated constructor stub
	}

}
