/**
 * 
 */
package com.hclhackathon.mobile.dao;

/**
 * @author hackathon
 *
 */
public class Response {

	/**
	 * 
	 */
	public Response() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
