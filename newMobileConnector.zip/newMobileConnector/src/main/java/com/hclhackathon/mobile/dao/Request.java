/**
 * 
 */
package com.hclhackathon.mobile.dao;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hclhackaton.mobile.controller.InputDataFields;

/**
 * @author hackathon
 *
 */
public class Request {

    @JsonProperty(value = "firstName", required = true)
    private String firstname;

    @JsonProperty(value = "lastName", required = true)
    private String lastname;

    @JsonProperty(value = "requestId", required = true)
    private String requestId;
    
    @JsonProperty(value = "email", required = true)
    private String email;
    
    @JsonProperty(value = "address")
    private String address;
    
    @JsonProperty(value = "ssn", required = true)
    private String ssn;
    
    @JsonProperty(value = "status", required = true)
    private String status;
    
    @JsonProperty(value = "comments", required = true)
    private String comments;
    
    @JsonProperty(value = "enabled", required = true)
    private String enabled;
    
    @JsonProperty(value = "mobileNumber", required = true)
    private String mobileNumber;
    
    @JsonProperty(value = "planId", required = true)
    private String planId;

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getSsn() {
		return ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getEnabled() {
		return enabled;
	}

	public void setEnabled(String enabled) {
		this.enabled = enabled;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getPlanId() {
		return planId;
	}

	public void setPlanId(String planId) {
		this.planId = planId;
	}
}
