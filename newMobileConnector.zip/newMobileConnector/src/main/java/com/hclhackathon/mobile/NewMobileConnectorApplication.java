package com.hclhackathon.mobile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewMobileConnectorApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewMobileConnectorApplication.class, args);
	}

}
